package com.apitest.apirest.usuariorepositorioimp;

public class UsuarioRepositorioImpl {

}
