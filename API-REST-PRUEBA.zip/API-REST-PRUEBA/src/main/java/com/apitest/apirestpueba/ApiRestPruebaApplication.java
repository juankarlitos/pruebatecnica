package com.apitest.apirestpueba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestPruebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestPruebaApplication.class, args);
	}

}
