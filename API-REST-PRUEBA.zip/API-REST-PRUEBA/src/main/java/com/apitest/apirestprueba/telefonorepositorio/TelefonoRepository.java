package com.apitest.apirestprueba.telefonorepositorio;

public interface TelefonoRepository {

}
