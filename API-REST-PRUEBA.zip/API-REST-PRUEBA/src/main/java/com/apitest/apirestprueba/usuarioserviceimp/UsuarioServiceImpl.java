package com.apitest.apirestprueba.usuarioserviceimp;

public class UsuarioServiceImpl {

}
