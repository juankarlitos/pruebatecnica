package com.apitest.apirestprueba.interfaztelefono;

public interface TelefonoServicio {

}
