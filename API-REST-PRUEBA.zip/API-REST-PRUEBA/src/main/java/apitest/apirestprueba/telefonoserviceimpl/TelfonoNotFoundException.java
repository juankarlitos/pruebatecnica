package apitest.apirestprueba.telefonoserviceimpl;

public class TelfonoNotFoundException extends Exception {

}
