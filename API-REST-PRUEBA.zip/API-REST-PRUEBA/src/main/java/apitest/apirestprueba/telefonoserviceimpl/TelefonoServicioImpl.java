package apitest.apirestprueba.telefonoserviceimpl;

public class TelefonoServicioImpl {

}
