package com.apitest.apirestpueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestPruebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
